from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import traceback


from telemetry import (
    tracer,
    request_counter,
    login_requests_total,
    home_views_total,
    cart_add_attempts_total,
    cart_add_errors_total,
    app_logger,
)

app = FastAPI(title="Python OTEL → Grafana Cloud Ecommerce Demo")

# Static & templates
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Catálogo simple en memoria
PRODUCTS = [
    {"id": 1, "name": "Laptop Pro 14\"", "price": 1499.00, "description": "Equipo ideal para desarrollo y data science."},
    {"id": 2, "name": "Mouse Inalámbrico", "price": 39.90, "description": "Preciso, ergonómico, perfecto para largas jornadas."},
    {"id": 3, "name": "Monitor 27\" 2K", "price": 299.00, "description": "Pantalla amplia para multitarea y dashboards."},
]


@app.get("/hello")
async def hello():
    # endpoint de prueba que ya tenías
    with tracer.start_as_current_span("hello-span") as span:
        span.set_attribute("endpoint", "/hello")
        span.set_attribute("component", "fastapi")
        request_counter.add(1, {"endpoint": "/hello"})
        app_logger.info("Aplicación ecommerce: /hello endpoint ha sido llamado")
        return {"message": "Hello from Python + OpenTelemetry + Grafana Cloud!"}


@app.get("/", response_class=HTMLResponse)
async def login_page(request: Request):
    with tracer.start_as_current_span("login-page"):
        login_requests_total.add(1, {"endpoint": "POST /login"})
        request_counter.add(1, {"endpoint": "GET /"})
        app_logger.info("Aplicación ecommerce: /hello endpoint ha sido llamado")
        return templates.TemplateResponse(
            "login.html",
            {"request": request}
        )


@app.post("/login", response_class=HTMLResponse)
async def login_submit(request: Request, username: str = Form("Invitado")):
    with tracer.start_as_current_span("login") as span:
        span.set_attribute("username", username)
        login_requests_total.add(1, {"endpoint": "POST /login"})
        app_logger.info(" Usuario %s ha iniciado sesión", username)
        request_counter.add(1, {"endpoint": "POST /login"})

    # No hay validación, siempre redirige al home
    response = RedirectResponse(url=f"/home?user={username}", status_code=303)
    return response


@app.get("/home", response_class=HTMLResponse)
async def home_page(request: Request, user: str = "Invitado"):
    with tracer.start_as_current_span("home") as span:
        span.set_attribute("user", user)
        home_views_total.add(1, {"endpoint": "GET /home"})
        app_logger.info(" Usuario %s ha accedido al home", user)
        request_counter.add(1, {"endpoint": "GET /home"})

    return templates.TemplateResponse(
        "home.html",
        {
            "request": request,
            "user": user,
            "products": PRODUCTS,
        }
    )


@app.get("/cart/{product_id}", response_class=HTMLResponse)
async def cart_page(request: Request, product_id: int, user: str = "Invitado"):
    product = next((p for p in PRODUCTS if p["id"] == product_id), None)

    # Span del TRY
    with tracer.start_as_current_span("cart-add-to-cart-try") as span_try:
        span_try.set_attribute("user", user)
        span_try.set_attribute("product.id", product_id)
        request_counter.add(1, {"endpoint": "GET /cart"})
        app_logger.info(" Usuario %s intenta añadir al carrito el producto %s", user, product_id)
        cart_add_attempts_total.add(1, {"endpoint": "GET /cart"})


        try:
            # Lógica "normal"
            if product is None:
                # Si el producto no existe, también es error
                raise ValueError(f"Producto con id {product_id} no encontrado")

            # 💥 Error TRÁGICO simulado SIEMPRE al añadir al carrito
            raise RuntimeError("Traceback (most recent call last): File c:\ruta\tu_script.py, line 4, in <module>   File c:\ruta\tu_script.py, line 2, [Previous line repeated 996 more times] RecursionError: maximum recursion depth exceeded")

        except Exception as e:
            # Generamos el stacktrace de Python en texto
            error_message = str(e)
            error_stacktrace = traceback.format_exc()
            cart_add_errors_total.add(1, {"endpoint": "GET /cart"})

            # Span del CATCH
            with tracer.start_as_current_span("cart-add-to-cart-catch") as span_catch:
                span_catch.set_attribute("user", user)
                span_catch.set_attribute("product.id", product_id)
                span_catch.set_attribute("error", True)
                span_catch.set_attribute("exception.type", type(e).__name__)
                span_catch.set_attribute("exception.message", error_message)
                span_catch.set_attribute("exception.stacktrace", error_stacktrace)
                span_catch.record_exception(e)
                app_logger.info(" Usuario %s ha tenido un error al añadir al carrito el producto %s: %s", user, product_id, error_message)

            # 🔥 Re-lanzamos la excepción para que FastAPI muestre el 500
            raise
