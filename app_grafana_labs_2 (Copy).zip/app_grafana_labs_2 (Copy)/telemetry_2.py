# telemetry.py
import os

from opentelemetry import trace, metrics
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter

# Nombre de servicio desde la variable de entorno estándar
service_name = os.getenv("OTEL_SERVICE_NAME", "python-otel-demo")

resource = Resource.create({
    "service.name": service_name,
     "service.namespace": "demo-ecommerce",
    "service.version": "1.0.0",
})

# ---------- TRACES ----------
tracer_provider = TracerProvider(resource=resource)

# Usa las variables OTEL_EXPORTER_OTLP_* configuradas en Windows
span_exporter = OTLPSpanExporter()
tracer_provider.add_span_processor(BatchSpanProcessor(span_exporter))

trace.set_tracer_provider(tracer_provider)
tracer = trace.get_tracer(__name__)

# ---------- METRICS ----------
metric_exporter = OTLPMetricExporter()
metric_reader = PeriodicExportingMetricReader(metric_exporter)

meter_provider = MeterProvider(
    resource=resource,
    metric_readers=[metric_reader],
)
metrics.set_meter_provider(meter_provider)
meter = metrics.get_meter(__name__)

# Métrica de ejemplo: contador de requests
request_counter = meter.create_counter(
    name="demo_requests_total",
    unit="1",
    description="Número de requests procesadas en /hello",
)


# NUEVAS MÉTRICAS DE NEGOCIO

# 1) Intentos de login
login_requests_total = meter.create_counter(
    name="ecommerce_login_requests_total",
    unit="1",
    description="Número de intentos de login en el ecommerce",
)

# 2) Visitas al home (catálogo)
home_views_total = meter.create_counter(
    name="ecommerce_home_views_total",
    unit="1",
    description="Número de veces que se visualiza el home de productos",
)

# 3) Intentos de añadir al carrito
cart_add_attempts_total = meter.create_counter(
    name="ecommerce_cart_add_attempts_total",
    unit="1",
    description="Intentos de añadir productos al carrito",
)

# 4) Errores al añadir al carrito
cart_add_errors_total = meter.create_counter(
    name="ecommerce_cart_add_errors_total",
    unit="1",
    description="Errores al intentar añadir productos al carrito",
)


# ---------------- LOGS (LOKI vía OTLP) ----------------
import os
import logging

from opentelemetry import _logs
from opentelemetry.sdk._logs import LoggerProvider, LoggingHandler
from opentelemetry.sdk._logs.export import BatchLogRecordProcessor
from opentelemetry.exporter.otlp.proto.http._log_exporter import OTLPLogExporter
from opentelemetry.sdk.resources import Resource

# -------- LoggerProvider + OTLP HTTP Log Exporter --------
logger_provider = LoggerProvider(resource=resource)

# Exportador OTLP/HTTP para logs.
# NO pasamos endpoint ni headers aquí para que use:
#   OTEL_EXPORTER_OTLP_ENDPOINT
#   OTEL_EXPORTER_OTLP_HEADERS
#   OTEL_EXPORTER_OTLP_PROTOCOL
otlp_log_exporter = OTLPLogExporter()

logger_provider.add_log_record_processor(
    BatchLogRecordProcessor(otlp_log_exporter)
)

# Registrar el provider global de logs
_logs.set_logger_provider(logger_provider)

# -------- Integrar con logging estándar de Python --------
otel_handler = LoggingHandler(
    level=logging.NOTSET,
    logger_provider=logger_provider,
)

root_logger = logging.getLogger()
root_logger.setLevel(logging.INFO)
root_logger.addHandler(otel_handler)

# Logger de aplicación que usarás en main.py
app_logger = logging.getLogger("otel_logs_demo")

