Paso 1: Crear la conexion al Opentelemetry OTLP
ir a:
DETAILS- -CONFIGURE
ENDPOINT:    https://otlp-gateway-prod-us-east-2.grafana.net/otlp
INSTANCE: ID 1436077
GENERAR TOKEN 
glc_eyJvIjoiMTU5OTcyMiIsIm4iOiJzdGFjay0xNDQ5NTE1LW90bHAtd3JpdGUtdG9rZW5fYXBwX2Vjb21tZXJjZV8xIiwiayI6IkpDdDB3VTM1RHc1Mm5MaG4xMUY5MjNIaiIsIm0iOnsiciI6InByb2QtdXMtZWFzdC0wIn19

Paso 2:
CREAR EL BASE64 DEL ID:TOKEN
Base 64 Windows
$texto = "1449515:glc_eyJvIjoiMTU5OTcyMiIsIm4iOiJzdGFjay0xNDQ5NTE1LW90bHAtd3JpdGUtdG9rZW5fYXBwX2Vjb21tZXJjZV8xIiwiayI6IkpDdDB3VTM1RHc1Mm5MaG4xMUY5MjNIaiIsIm0iOnsiciI6InByb2QtdXMtZWFzdC0wIn19"
$bytes = [System.Text.Encoding]::UTF8.GetBytes($texto)
[Convert]::ToBase64String($bytes)

Base 64 Linux 
echo "id:token" | base64

MTQ0OTUxNTpnbGNfZXlKdklqb2lNVFU1T1RjeU1pSXNJbTRpT2lKemRHRmpheTB4TkRRNU5URTFM
VzkwYkhBdGQzSnBkR1V0ZEc5clpXNWZZWEJ3WDJWamIyMXRaWEpqWlY4eElpd2lheUk2SWtwRGRE
QjNWVE0xUkhjMU1tNU1hRzR4TVVZNU1qTklhaUlzSW0waU9uc2ljaUk2SW5CeWIyUXRkWE10WldG
emRDMHdJbjE5Cg==


Paso 3:
Crear las variables de entorno puede ser por terminal asi:

export OTEL_EXPORTER_OTLP_PROTOCOL="http/protobuf"
export OTEL_EXPORTER_OTLP_ENDPOINT="https://otlp-gateway-prod-us-east-2.grafana.net/otlp"
export OTEL_EXPORTER_OTLP_HEADERS="Authorization=Basic%20MTQ0OTUxNTpnbGNfZXlKdklqb2lNVFU1T1RjeU1pSXNJbTRpT2lKemRHRmpheTB4TkRRNU5URTFMVzkwYkhBdGQzSnBkR1V0ZEc5clpXNWZZWEJ3WDJWamIyMXRaWEpqWlY4eElpd2lheUk2SWtwRGREQjNWVE0xUkhjMU1tNU1hRzR4TVVZNU1qTklhaUlzSW0waU9uc2ljaUk2SW5CeWIyUXRkWE10WldGemRDMHdJbjE5"

O bien se crea un .env con las varibles para que sean leidas desde el codigo de la aplicacion.

Paso 4: 
Si se tiene bien instrumentado el codigo con Opentelemetry esto ya va a enviar trazas a Grafana
Se puede probar en Explore - Tempo 

Paso 5:
Crear el Script para tener metricas de experiencia de usuario

FRONTEND USER EXPERIENCE:
GRAFANA-> OBSERVABILITY->FRONTEND
CREATE NEW -> aPP NAME + DOMAIN + ATRIBUTES
cOPIAR EL SCRIPT DESDE CDN Y PEGARLO EN LA BASE DEL HTML ANTES DEL CIERRE DEL BODY

Paso 6:
APM con Grafana Alloy (Linux)
https://grafana.com/docs/grafana-cloud/send-data/alloy/set-up/install/linux/

- sudo apt install gpg
- sudo mkdir -p /etc/apt/keyrings/
wget -q -O - https://apt.grafana.com/gpg.key | gpg --dearmor | sudo tee /etc/apt/keyrings/grafana.gpg > /dev/null
echo "deb [signed-by=/etc/apt/keyrings/grafana.gpg] https://apt.grafana.com stable main" | sudo tee /etc/apt/sources.list.d/grafana.list
- sudo apt-get update
- sudo apt-get install alloy 
(Las instalacion de Alloy en Linux queda en etc/alloy)
- sudo touch /etc/alloy/config.alloy
- sudo nano /etc/alloy/config.alloy (Pegar esta configuracion-Se debe ir a Stack-Prometheus y sacar los datos de alli)

// --- LOGGING BÁSICO (opcional pero útil) ---
logging {
  level  = "info"
  format = "logfmt"
}

// --- 1) ENVIAR MÉTRICAS A GRAFANA CLOUD (metrics_service) ---
prometheus.remote_write "metrics_service" {
  endpoint {
    // COPIA ESTA URL EXACTA DEL PORTAL DE GRAFANA CLOUD
    // (Prometheus -> "Send metrics" / "Remote write / Alloy")
    url = "https://prometheus-prod-XX.grafana.net/api/prom/push"

    basic_auth {
      // ID de la instancia de métricas (número que te da Grafana Cloud)
      username = "123456"

      // API key leída desde variable de entorno
      password = sys.env("GCLOUD_RW_API_KEY")
    }
  }
}

(Debajo de esto en el mismo archivo config.alloy) se debe poner el snippet que se saca de 
Connection - Add Connection - Linux)

- sudo systemctl daemon-reload   # solo por si acaso
- sudo systemctl restart alloy
- sudo systemctl status alloy (debe estar running)
Con esto ya se envian metricas de maquina a Grafana.

EXPLORE:
{ resource.service.name = "python-ecommerce" }
ecommerce_login_requests_total
ecommerce_home_views_total
ecommerce_cart_add_attempts_total
ecommerce_cart_add_errors_total
{service_name="python-ecommerce"}