fastapi
uvicorn[standard]

opentelemetry-api
opentelemetry-sdk
opentelemetry-exporter-otlp-proto-http
opentelemetry-exporter-otlp
python-multipart
jinja2
python-loki

'''
uvicorn main:app --reload --port 8000

OTLP TRAZAS:
DETAILS- -CONFIGURE
ENDPOINT:    https://otlp-gateway-prod-us-east-2.grafana.net/otlp
INSTANCE: ID 1436077
TOKEN glc_eyJvIjoiMTU4NzY0OCIsIm4iOiJzdGFjay0xNDM2MDc3LW90bHAtd3JpdGUtbGFic18yXzIiLCJrIjoiMUNqUFkxdTU0anVjbk05MUlWR2I5MjQ2IiwibSI6eyJyIjoicHJvZC11cy1lYXN0LTAifX0=

DESDE GRAFANA SE CREA ESTE CODIGO PERO NO SIRVE POR QUE TOCA GENERAR EL BASE64
export OTEL_EXPORTER_OTLP_PROTOCOL="http/protobuf"
export OTEL_EXPORTER_OTLP_ENDPOINT="https://otlp-gateway-prod-us-east-2.grafana.net/otlp"
export OTEL_EXPORTER_OTLP_HEADERS="Authorization=Basic MTQzNjA3NzpnbGNfZXlKdklqb2lNVFU0TnpZME9DSXNJbTRpT2lKemRHRmpheTB4TkRNMk1EYzNMVzkwYkhBdGQzSnBkR1V0YkdGaWMxOHlYeklpTENKcklqb2lNVU5xVUZreGRUVTBhblZqYmswNU1VbFdSMkk1TWpRMklpd2liU0k2ZXlKeUlqb2ljSEp2WkMxMWN5MWxZWE4wTFRBaWZYMD0="

CODIGO PARA GENERAR EL BASE64 DESDE POWERSHELL INSTANCEID:TOKEN
$texto = "1436077:glc_eyJvIjoiMTU4NzY0OCIsIm4iOiJzdGFjay0xNDM2MDc3LW90bHAtd3JpdGUtbGFic18yXzIiLCJrIjoiMUNqUFkxdTU0anVjbk05MUlWR2I5MjQ2IiwibSI6eyJyIjoicHJvZC11cy1lYXN0LTAifX0="
$bytes = [System.Text.Encoding]::UTF8.GetBytes($texto)
[Convert]::ToBase64String($bytes)

ESTE ES EL BASE64
MTQzNjA3NzpnbGNfZXlKdklqb2lNVFU0TnpZME9DSXNJbTRpT2lKemRHRmpheTB4TkRNMk1EYzNMVzkwYkhBdGQzSnBkR1V0YkdGaWMxOHlYeklpTENKcklqb2lNVU5xVUZreGRUVTBhblZqYmswNU1VbFdSMkk1TWpRMklpd2liU0k2ZXlKeUlqb2ljSEp2WkMxMWN5MWxZWE4wTFRBaWZYMD0=

SE CAMBIAN LAS VARIABLES DE ENTORNO EN POWERSHELL ADICIONANDO EL BASE 64 DESPUES DE BASIC%20
$env:OTEL_EXPORTER_OTLP_ENDPOINT = "https://otlp-gateway-prod-us-east-2.grafana.net/otlp"
$env:OTEL_EXPORTER_OTLP_PROTOCOL = "http/protobuf"
$env:OTEL_EXPORTER_OTLP_HEADERS  = "Authorization=Basic%20MTQzNjA3NzpnbGNfZXlKdklqb2lNVFU0TnpZME9DSXNJbTRpT2lKemRHRmpheTB4TkRNMk1EYzNMVzkwYkhBdGQzSnBkR1V0YkdGaWMxOHlYeklpTENKcklqb2lNVU5xVUZreGRUVTBhblZqYmswNU1VbFdSMkk1TWpRMklpd2liU0k2ZXlKeUlqb2ljSEp2WkMxMWN5MWxZWE4wTFRBaWZYMD0="



FRONTEND USER EXPERIENCE:
GRAFANA-> OBSERVABILITY->FRONTEND
CREATE NEW -> aPP NAME + DOMAIN + ATRIBUTES
cOPIAR EL SCRIPT DESDE CDN Y PEGARLO EN LA BASE DEL HTML ANTES DEL CIERRE DEL BODY


LOGS:
Instrumentacion por opentelemetry
from opentelemetry import _logs
from opentelemetry.sdk._logs import LoggerProvider, LoggingHandler
from opentelemetry.sdk._logs.export import BatchLogRecordProcessor
from opentelemetry.exporter.otlp.proto.http._log_exporter import OTLPLogExporter

Enviar en cada Endpoint de la aplicacion un LoggerProvider
Grafana-Aplicacion-logs: {service_name="python-otel-demo"}

INFRA:

cd "%TEMP%" && powershell -c Invoke-WebRequest "https://storage.googleapis.com/cloud-onboarding/alloy/scripts/install-windows.ps1" -OutFile "install-windows.ps1" && powershell -executionpolicy Bypass -File ".\install-windows.ps1" -GCLOUD_RW_API_KEY "glc_eyJvIjoiMTU4NzY0OCIsIm4iOiJzdGFjay0xNDM2MDc3LWFsbG95LWxhYnNfMl8yX2hvc3QiLCJrIjoiNDRoUVZINGRNTEFSMThuSDBCRTg5NzlmIiwibSI6eyJyIjoicHJvZC11cy1lYXN0LTAifX0=" -GCLOUD_HOSTED_METRICS_ID "2796387" -GCLOUD_HOSTED_METRICS_URL "https://prometheus-prod-56-prod-us-east-2.grafana.net/api/prom/push" -GCLOUD_HOSTED_LOGS_ID "1393871" -GCLOUD_HOSTED_LOGS_URL "https://logs-prod-036.grafana.net/loki/api/v1/push" -GCLOUD_FM_URL "https://fleet-management-prod-008.grafana.net" -GCLOUD_FM_POLL_FREQUENCY "60s" -GCLOUD_FM_HOSTED_ID "1436077"

cd "%TEMP%" && powershell -c Invoke-WebRequest "https://storage.googleapis.com/cloud-onboarding/alloy/scripts/install-windows.ps1" -OutFile "install-windows.ps1" && powershell -executionpolicy Bypass -File ".\install-windows.ps1" -GCLOUD_RW_API_KEY "glc_eyJvIjoiMTU4NzY0OCIsIm4iOiJzdGFjay0xNDM2MDc3LWFsbG95LWxhYnNfMl8yX2hvc3RfMiIsImsiOiJNMTVZM1lmNmRZVzFwTTg0MVNhVm8zMUwiLCJtIjp7InIiOiJwcm9kLXVzLWVhc3QtMCJ9fQ==" -GCLOUD_HOSTED_METRICS_ID "2796387" -GCLOUD_HOSTED_METRICS_URL "https://prometheus-prod-56-prod-us-east-2.grafana.net/api/prom/push" -GCLOUD_HOSTED_LOGS_ID "1393871" -GCLOUD_HOSTED_LOGS_URL "https://logs-prod-036.grafana.net/loki/api/v1/push" -GCLOUD_FM_URL "https://fleet-management-prod-008.grafana.net" -GCLOUD_FM_POLL_FREQUENCY "60s" -GCLOUD_FM_HOSTED_ID "1436077"

cd "%TEMP%" && powershell -c 
Invoke-WebRequest "https://storage.googleapis.com/cloud-onboarding/alloy/scripts/install-windows.ps1" 
-OutFile "install-windows.ps1" && powershell -executionpolicy Bypass -File ".\install-windows.ps1" 
-GCLOUD_RW_API_KEY "glc_eyJvIjoiMTU4NzY0OCIsIm4iOiJzdGFjay0xNDM2MDc3LWFsbG95LWxhYnNfMl8yX2hvc3RfMiIsImsiOiJNMTVZM1lmNmRZVzFwTTg0MVNhVm8zMUwiLCJtIjp7InIiOiJwcm9kLXVzLWVhc3QtMCJ9fQ==" 
-GCLOUD_HOSTED_METRICS_ID "2796387" 
-GCLOUD_HOSTED_METRICS_URL "https://prometheus-prod-56-prod-us-east-2.grafana.net/api/prom/push" 
-GCLOUD_HOSTED_LOGS_ID "1393871" 
-GCLOUD_HOSTED_LOGS_URL "https://logs-prod-036.grafana.net/loki/api/v1/push" 
-GCLOUD_FM_URL "https://fleet-management-prod-008.grafana.net" 
-GCLOUD_FM_POLL_FREQUENCY "60s" 
-GCLOUD_FM_HOSTED_ID "1436077"

set GCLOUD_RW_API_KEY=glc_eyJvIjoiMTU4NzY0OCIsIm4iOiJzdGFjay0xNDM2MDc3LWFsbG95LWxhYnNfMl8yX2hvc3RfMiIsImsiOiJNMTVZM1lmNmRZVzFwTTg0MVNhVm8zMUwiLCJtIjp7InIiOiJwcm9kLXVzLWVhc3QtMCJ9fQ==
set GCLOUD_HOSTED_METRICS_ID=2796387
set GCLOUD_HOSTED_METRICS_URL=https://prometheus-prod-56-prod-us-east-2.grafana.net/api/prom/push
set GCLOUD_HOSTED_LOGS_ID=1393871
set GCLOUD_HOSTED_LOGS_URL=https://logs-prod-036.grafana.net/loki/api/v1/push
set GCLOUD_FM_URL=https://fleet-management-prod-008.grafana.net
set GCLOUD_FM_POLL_FREQUENCY=60s
set GCLOUD_FM_HOSTED_ID=1436077



EXPLORE:
TEMPO
{ resource.service.name = "python-otel-demo" }

MIMIR
ecommerce_login_requests_total
ecommerce_home_views_total
ecommerce_cart_add_attempts_total
ecommerce_cart_add_errors_total

LOKI
Grafana-Aplicacion-logs: {service_name="python-otel-demo"}


DASHBOARDS:

'''



grafanaprueba125112025@gmail.com