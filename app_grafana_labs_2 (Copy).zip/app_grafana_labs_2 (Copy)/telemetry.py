# telemetry.py

import os
import logging

from dotenv import load_dotenv
from opentelemetry import trace, metrics, _logs

# SDK base
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader

from opentelemetry.sdk._logs import LoggerProvider, LoggingHandler
from opentelemetry.sdk._logs.export import BatchLogRecordProcessor

# OTLP EXPORTERS
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter
from opentelemetry.exporter.otlp.proto.http._log_exporter import OTLPLogExporter


# =========================================================
# -----------      LOAD .ENV (python-dotenv)    -----------
# =========================================================

# Carga variables del archivo .env en el entorno
load_dotenv()


# =========================================================
# -----------      READ ENVIRONMENT VARIABLES    ----------
# =========================================================

def parse_headers():
    """
    Transforma:
    OTEL_EXPORTER_OTLP_HEADERS="Authorization=Basic xxxx"

    en:
    {"Authorization": "Basic xxxx"}
    """
    headers_env = os.getenv("OTEL_EXPORTER_OTLP_HEADERS", "")
    # Por si acaso viniera con %20 desde algún copy/paste
    headers_env = headers_env.replace("%20", " ")

    headers = {}
    for h in headers_env.split(","):
        if "=" in h:
            k, v = h.split("=", 1)
            headers[k.strip()] = v.strip()
    return headers


def build_endpoint(explicit: str | None, base: str | None, suffix: str) -> str:
    """
    Si hay endpoint específico (TRACES/METRICS/LOGS) lo usa.
    Si no, construye a partir del endpoint base + sufijo (/v1/traces, etc).
    Si no hay nada, lanza un error entendible.
    """
    if explicit:
        return explicit
    if base:
        return base.rstrip("/") + suffix
    raise RuntimeError(
        f"Falta configurar OTEL_EXPORTER_OTLP_ENDPOINT o endpoint específico para {suffix}"
    )


# ENDPOINTS explícitos (si existen)
endpoint_traces = os.getenv("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT")
endpoint_metrics = os.getenv("OTEL_EXPORTER_OTLP_METRICS_ENDPOINT")
endpoint_logs = os.getenv("OTEL_EXPORTER_OTLP_LOGS_ENDPOINT")

# ENDPOINT general como fallback
endpoint_base = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT")

headers = parse_headers()


# =========================================================
# -----------     RESOURCE (SERVICE ATTRIBUTES)   ---------
# =========================================================

resource = Resource.create({
    "service.name": os.getenv("OTEL_SERVICE_NAME", "python-service"),
    "service.namespace": "demo-ecommerce",
    "service.version": "1.0.0",
})


# =========================================================
# ------------------------ TRACES -------------------------
# =========================================================

tracer_provider = TracerProvider(resource=resource)

span_exporter = OTLPSpanExporter(
    endpoint=build_endpoint(endpoint_traces, endpoint_base, "/v1/traces"),
    headers=headers or None,
)

tracer_provider.add_span_processor(BatchSpanProcessor(span_exporter))
trace.set_tracer_provider(tracer_provider)
tracer = trace.get_tracer(__name__)


# =========================================================
# ----------------------- METRICS -------------------------
# =========================================================

metric_exporter = OTLPMetricExporter(
    endpoint=build_endpoint(endpoint_metrics, endpoint_base, "/v1/metrics"),
    headers=headers or None,
)

metric_reader = PeriodicExportingMetricReader(metric_exporter)

meter_provider = MeterProvider(
    resource=resource,
    metric_readers=[metric_reader],
)

metrics.set_meter_provider(meter_provider)
meter = metrics.get_meter(__name__)


# Métricas de ejemplo / negocio
request_counter = meter.create_counter(
    name="demo_requests_total",
    unit="1",
    description="Número de requests procesadas.",
)

login_requests_total = meter.create_counter(
    name="ecommerce_login_requests_total",
    unit="1",
    description="Intentos de login",
)

home_views_total = meter.create_counter(
    name="ecommerce_home_views_total",
    unit="1",
    description="Vistas al home",
)

cart_add_attempts_total = meter.create_counter(
    name="ecommerce_cart_add_attempts_total",
    unit="1",
    description="Intentos de añadir al carrito",
)

cart_add_errors_total = meter.create_counter(
    name="ecommerce_cart_add_errors_total",
    unit="1",
    description="Errores al añadir al carrito",
)


# =========================================================
# ------------------------- LOGS --------------------------
# =========================================================

logger_provider = LoggerProvider(resource=resource)

log_exporter = OTLPLogExporter(
    endpoint=build_endpoint(endpoint_logs, endpoint_base, "/v1/logs"),
    headers=headers or None,
)

logger_provider.add_log_record_processor(
    BatchLogRecordProcessor(log_exporter)
)

_logs.set_logger_provider(logger_provider)

otel_handler = LoggingHandler(
    level=logging.NOTSET,
    logger_provider=logger_provider,
)

root_logger = logging.getLogger()
root_logger.setLevel(logging.INFO)
root_logger.addHandler(otel_handler)

app_logger = logging.getLogger("otel_logs_demo")
